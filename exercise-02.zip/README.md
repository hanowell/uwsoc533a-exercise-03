# uwsoc533a-exercise-02
Exercise 2 for UW SOC/CS&amp;SS/CSDE 533 A Winter Quarter 2022
